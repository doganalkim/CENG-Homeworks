#include "parser.h"
#include "pipeline.h"

void para_exec(parsed_input *pi);
void para_exec_helper(single_input *si);