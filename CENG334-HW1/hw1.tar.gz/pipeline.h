#include "scmd.h"

void generic_pipe_exec(pipeline *pl);
//void pipe_exec_helper(single_input *si);
void pipe_exec(parsed_input *pi);