#include "parser.h"
#include "scmd.h"
#include "pipeline.h"


void seq_exec_helper(single_input *si);
void seq_exec(parsed_input *pi);
